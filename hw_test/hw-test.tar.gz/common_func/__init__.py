import func
